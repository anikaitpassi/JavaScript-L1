var a = prompt("Enter first number");
var b = prompt("Enter second number");
var x=parseInt(a);
var y=parseInt(b);

alert(x+y);