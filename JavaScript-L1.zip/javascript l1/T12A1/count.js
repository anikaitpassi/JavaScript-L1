function countOptions(){
  alert("There are "+
    document.getElementById("lst").length
    + " items in list.");
}

