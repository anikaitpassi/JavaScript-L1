var var_name = 'abcd';
var n = 120;
this[var_name] = n;
console.log(this[var_name])
document.write(this[var_name])