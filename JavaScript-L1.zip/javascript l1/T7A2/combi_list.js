var newlist = function()
{
let array1 = ['a','b','c'];
let array2 = [1,2,3];
let l = array1.length + array2.length;
let r=[];
let j=0,k=0;
for(let i=0;i<l;i++)
{
	if(i%2==0)
		r[i]=array1[j++];
	else
		r[i]=array2[k++];

}
return r;
}
console.log(newlist());
document.write(newlist());