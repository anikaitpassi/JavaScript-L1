a=-5;
b=-2;
c=6;
d= 0;
f=-1;
if (a>b && a>c && a>d && a>f)
{
    alert(a);
}
else if (b>a && b>c && b>d && b>f)
{
    alert(b);
}
else if (c>a && c>b && c>d && c>f)
{
    alert(c);
}
else if (d>a && d>c && d>b && d>f)
{
    alert(d);
}
else
{
    alert(f);
}