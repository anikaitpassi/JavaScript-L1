function msg()
{  
 alert("Hello User");  
}  