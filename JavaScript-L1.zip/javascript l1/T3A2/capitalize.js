  function capitalize_Words(str)
{
 return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}
console.log(capitalize_Words('write a javaScript program to capitalize the first letter of each word of a given string and display it on java script console along with browser'));
document.write(capitalize_Words('write a javaScript program to capitalize the first letter of each word of a given string and display it on java script console along with browser'));
       