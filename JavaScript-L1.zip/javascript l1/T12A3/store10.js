var items = [];
function displayArr() {

for(var i=0;i<10;i++)
{
  items[i]=prompt("enter "+ (i+1) + " employee name:-");
  
  var res = items.filter((_,i) => !(i % 2));

document.getElementById("demo").innerHTML=res.join("<br>");

}console.log(res);
}