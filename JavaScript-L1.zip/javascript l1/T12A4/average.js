var marks=[65,93,23,84,74,96,45,89];
var avgmarks=0;
for(var i=0;i<marks.length;i++)
{
  avgmarks+=marks[i];
  var avg=(avgmarks/marks.length);
}
document.writeln("average marks:"+avg);
console.log(avg);