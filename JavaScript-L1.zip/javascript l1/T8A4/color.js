function customAction(){
		//setTimeout(function(){
			changeColors().then(function(){
				setTimeout(function(){
					var nxtStep = prompt("Do you want to continue ?", "No");
					if(nxtStep=="Yes" || nxtStep=="yes"){
						customAction();
					}
				}, 0);
			});
			
		//} , 0);
	}
	function changeColors(callback) {
		var bgColor = prompt("Enter your favorite background color", "black");
		if(bgColor != null && bgColor != "") {
			document.querySelector("#mainContent").style.backgroundColor=bgColor;
			var fColor = prompt("Enter your favorite foreground color", "white");
			if(fColor != null && fColor != "") {
				document.querySelector("#mainContent").style.color=fColor;
			} 
		} 
		return new Promise(function (fulfill, reject){	
			fulfill(true); //if the action succeeded
			reject(false); //if the action did not succeed
		});
	}