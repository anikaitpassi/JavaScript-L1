function donate()
{
   var amount=prompt("please enter amount u wish to donate");
   var finalAmount=Math.round(amount);
   alert("thank you for donation of $"+ finalAmount);
}