function division(){
	num=document.getElementById("num").value;
	den=document.getElementById("den").value;

	try{
		if(den==0){
			throw("denom cannot be 0!");

		    }
		else{
			document.getElementById("result").innerHTML=num/den;
		    }
	}
	catch(e){
		document.getElementById("result").innerHTML=("error: "+e);
        	}
}