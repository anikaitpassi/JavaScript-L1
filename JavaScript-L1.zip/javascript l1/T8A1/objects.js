var CD={};
function insertVal()
{
    CD['Name']=document.getElementById("cdN").value;
    CD['Publisher']=document.getElementById("cdP").value;
    CD['Price']=document.getElementById("cdPr").value;

displayAllDetails();
}

function displayAllDetails(){

    document.getElementById("cdName").innerHTML+=CD.Name;
    document.getElementById("cdPub").innerHTML+=CD.Publisher;

    var price1=parseInt(CD.Price);
    price1+=((price1+10)/100);
    price1-=((price1+3)/100);
    document.getElementById("cdPrice").innerHTML+=price1;
    document.getElementById("display").style.display="inline-block";
}