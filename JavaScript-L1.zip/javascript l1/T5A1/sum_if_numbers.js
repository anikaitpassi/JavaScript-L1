function sumifnum(a,b) 
{
var x=a; 
var y=b; 
var z=x+y;
if (typeof x=='number' && typeof y=='number') {
	document.write(z);
}
else
   alert ("Sorry.... Only Nos will be added");
}
sumifnum(3,'av'); //change 2nd value to number to run the if block

