var x=10;
var y=-7;
var z=0;
if (x>0 && y>0 && z>0)
{
       alert("The sign is +");
}
else if (x<0 && y<0 && z<0)
        {
          alert("The sign is +");
        }
        else if (x>0 && y<0 && z<0)
        {
          alert("The sign is +");
        }
        else if (x<0 && y>0 && z<0)
        {
          alert("The sign is +");
        }
        else
        {
          alert("The sign is -");
        }
		