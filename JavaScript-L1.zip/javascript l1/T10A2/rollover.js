	
 function move_in(img_name,img_src) {
   document[img_name].src=img_src;
   }

   function move_out(img_name,img_src) {
   document[img_name].src=img_src;
   }
  
